import nodemailer from "nodemailer";
import { ENV } from "./env";

let transporter: ReturnType<typeof nodemailer.createTransport> | null = null;

/**
 * Initialize the email transporter with SMTP configuration
 */
function getTransporter() {
  if (transporter) {
    return transporter;
  }

  if (!ENV.smtpHost || !ENV.smtpPort || !ENV.smtpUser || !ENV.smtpPassword) {
    console.error("[Email] SMTP configuration is incomplete");
    return null;
  }

  transporter = nodemailer.createTransport({
    host: ENV.smtpHost,
    port: parseInt(ENV.smtpPort, 10),
    secure: parseInt(ENV.smtpPort, 10) === 465, // Use TLS if port is 465
    auth: {
      user: ENV.smtpUser,
      pass: ENV.smtpPassword,
    },
  });

  return transporter;
}

export interface EmailPayload {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

/**
 * Send an email via SMTP
 */
export async function sendEmail(payload: EmailPayload): Promise<boolean> {
  const transporter = getTransporter();

  if (!transporter) {
    console.error("[Email] Email transporter not configured");
    return false;
  }

  try {
    await transporter.sendMail({
      from: ENV.smtpUser,
      to: payload.to,
      subject: payload.subject,
      text: payload.text,
      html: payload.html,
    });

    console.log(`[Email] Successfully sent email to ${payload.to}`);
    return true;
  } catch (error) {
    console.error("[Email] Failed to send email:", error);
    return false;
  }
}

/**
 * Send a contact form notification email to the portfolio owner
 */
export async function sendContactNotificationEmail(
  senderName: string,
  senderEmail: string,
  message: string,
  recipientEmail: string
): Promise<boolean> {
  const htmlContent = `
    <h2>New Portfolio Contact Submission</h2>
    <p><strong>From:</strong> ${escapeHtml(senderName)}</p>
    <p><strong>Email:</strong> <a href="mailto:${escapeHtml(senderEmail)}">${escapeHtml(senderEmail)}</a></p>
    <hr />
    <h3>Message:</h3>
    <p>${escapeHtml(message).replace(/\n/g, "<br />")}</p>
  `;

  const textContent = `
New Portfolio Contact Submission

From: ${senderName}
Email: ${senderEmail}

Message:
${message}
  `;

  return sendEmail({
    to: recipientEmail,
    subject: `New Contact: ${senderName}`,
    html: htmlContent,
    text: textContent,
  });
}

/**
 * Escape HTML special characters to prevent injection
 */
function escapeHtml(text: string): string {
  const map: Record<string, string> = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;",
  };
  return text.replace(/[&<>"']/g, (char) => map[char]);
}
