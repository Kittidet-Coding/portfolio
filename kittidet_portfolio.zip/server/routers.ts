import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { saveContactSubmission } from "./db";
import { notifyOwner } from "./_core/notification";
import { sendContactNotificationEmail } from "./_core/email";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  contact: router({
    submit: publicProcedure
      .input(
        z.object({
          name: z.string().min(1, "Name is required").max(255),
          email: z.string().email("Valid email is required"),
          message: z.string().min(1, "Message is required").max(5000),
        })
      )
      .mutation(async ({ input }) => {
        try {
          // Save to database
          await saveContactSubmission({
            name: input.name,
            email: input.email,
            message: input.message,
          });

          // Send email to portfolio owner
          await sendContactNotificationEmail(
            input.name,
            input.email,
            input.message,
            "kittidet.l@outlook.com"
          );

          // Notify owner via Manus notification system
          await notifyOwner({
            title: "New Portfolio Contact",
            content: `New message from ${input.name} (${input.email}):\n\n${input.message}`,
          });

          return {
            success: true,
            message: "Thank you for reaching out! I'll get back to you soon.",
          };
        } catch (error) {
          console.error("Contact submission error:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to submit contact form",
          });
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
