import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useRef, useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Loader2, Menu, X, ExternalLink } from "lucide-react";
import { APP_LOGO, APP_TITLE } from "@/const";

const PROJECTS = [
  {
    id: 1,
    title: "Technical Support & Implementation Team Leader",
    company: "Cendyn",
    description: "Led a team supporting Cendyn's product suite, managing P1/Critical issues and successfully implementing endpoint servers and APIs for over 100 clients.",
    tags: ["Leadership", "Data Integration", "People Management"],
  },
  {
    id: 2,
    title: "IT Manager",
    company: "Minor Hotels & Holiday Inn",
    description: "Planned and executed IT projects, managed budgets, and ensured data security while coordinating with various departments to meet technology needs in the hospitality sector.",
    tags: ["IT Management", "Project Management", "Hospitality IT"],
  },
  {
    id: 3,
    title: "Technical Support Specialist",
    company: "LSEG",
    description: "Delivered expert trading support for Refinitiv products, collaborating with product support teams and vendors to resolve customer issues effectively.",
    tags: ["Technical Support", "Problem Solving"],
  },
  {
    id: 4,
    title: "Senior Security Engineer",
    company: "Quantiq",
    description: "Developed IT security solutions, managed product portfolios, and designed sales strategies to enhance security offerings for clients.",
    tags: ["Network Security", "System Security"],
  },
];

const SKILLS = [
  { name: "Leadership & Management", proficiency: 95 },
  { name: "IT Management", proficiency: 90 },
  { name: "Project Management", proficiency: 92 },
  { name: "Data Integration (ETL/DBA)", proficiency: 88 },
  { name: "Data Engineering", proficiency: 85 },
  { name: "System Administration", proficiency: 87 },
  { name: "Cloud Management", proficiency: 80 },
  { name: "Generative AI", proficiency: 75 },
];

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [formData, setFormData] = useState({ name: "", email: "", message: "" });
  const contactRef = useRef<HTMLDivElement>(null);
  const submitMutation = trpc.contact.submit.useMutation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      toast.error("Please fill in all fields");
      return;
    }

    submitMutation.mutate(formData, {
      onSuccess: () => {
        toast.success("Message sent successfully!");
        setFormData({ name: "", email: "", message: "" });
      },
      onError: (error) => {
        toast.error(error.message || "Failed to send message");
      },
    });
  };

  const scrollToSection = (ref: React.RefObject<HTMLDivElement | null>) => {
    ref.current?.scrollIntoView({ behavior: "smooth" });
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              {APP_LOGO && <img src={APP_LOGO} alt="Logo" className="h-8 w-8" />}
              <span className="text-xl font-bold text-blue-600">Kittidet Lakthong</span>
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex gap-8">
              <a href="#about" className="text-gray-700 hover:text-blue-600 transition">About</a>
              <a href="#portfolio" className="text-gray-700 hover:text-blue-600 transition">Portfolio</a>
              <a href="#skills" className="text-gray-700 hover:text-blue-600 transition">Skills</a>
              <a href="#contact" className="text-gray-700 hover:text-blue-600 transition">Contact</a>
            </div>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden pb-4 space-y-2">
              <a href="#about" className="block px-4 py-2 text-gray-700 hover:bg-gray-100 rounded">About</a>
              <a href="#portfolio" className="block px-4 py-2 text-gray-700 hover:bg-gray-100 rounded">Portfolio</a>
              <a href="#skills" className="block px-4 py-2 text-gray-700 hover:bg-gray-100 rounded">Skills</a>
              <a href="#contact" className="block px-4 py-2 text-gray-700 hover:bg-gray-100 rounded">Contact</a>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section id="about" className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-blue-50 to-indigo-50">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
                Kittidet Lakthong
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                A results-driven Technical Team Lead and experienced IT Manager with a proven record in the hospitality industry. I specialize in leading technical support teams, driving complex data and software-related problem-solving, and managing the full lifecycle of IT projects.
              </p>
              <div className="flex gap-4">
                <Button
                  size="lg"
                  onClick={() => scrollToSection(contactRef)}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Get in Touch
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  onClick={() => document.getElementById("portfolio")?.scrollIntoView({ behavior: "smooth" })}
                >
                  View My Work
                </Button>
              </div>
            </div>
            <div className="flex justify-center">
              <img
                src="/headshot.jpg"
                alt="Kittidet Lakthong - Professional Headshot"
                className="w-80 h-80 rounded-lg shadow-xl object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-gray-900 mb-4 text-center">My Portfolio</h2>
          <p className="text-gray-600 text-center mb-12 max-w-2xl mx-auto">
            Here's a selection of projects I've worked on. Feel free to explore my professional experience and achievements.
          </p>

          <div className="grid md:grid-cols-2 gap-8">
            {PROJECTS.map((project) => (
              <div
                key={project.id}
                className="bg-white border border-gray-200 rounded-lg p-8 hover:shadow-lg transition-shadow"
              >
                <h3 className="text-2xl font-bold text-gray-900 mb-2">{project.title}</h3>
                <p className="text-blue-600 font-semibold mb-4">{project.company}</p>
                <p className="text-gray-600 mb-6">{project.description}</p>
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-gray-900 mb-4 text-center">My Expertise</h2>
          <p className="text-gray-600 text-center mb-12">
            A look at the technologies and tools I'm proficient with.
          </p>

          <div className="space-y-8">
            {SKILLS.map((skill) => (
              <div key={skill.name}>
                <div className="flex justify-between mb-2">
                  <span className="font-semibold text-gray-900">{skill.name}</span>
                  <span className="text-blue-600 font-bold">{skill.proficiency}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div
                    className="bg-gradient-to-r from-blue-500 to-indigo-600 h-3 rounded-full transition-all duration-500"
                    style={{ width: `${skill.proficiency}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" ref={contactRef} className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-4xl font-bold text-gray-900 mb-4 text-center">Get In Touch</h2>
          <p className="text-gray-600 text-center mb-12">
            Have a project in mind or just want to say hi? I'd love to hear from you.
          </p>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-900 mb-2">Name</label>
              <Input
                type="text"
                placeholder="Your name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                disabled={submitMutation.isPending}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-900 mb-2">Email</label>
              <Input
                type="email"
                placeholder="your@email.com"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                disabled={submitMutation.isPending}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-900 mb-2">Message</label>
              <Textarea
                placeholder="Your message..."
                rows={6}
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                disabled={submitMutation.isPending}
              />
            </div>

            <Button
              type="submit"
              size="lg"
              className="w-full bg-blue-600 hover:bg-blue-700"
              disabled={submitMutation.isPending}
            >
              {submitMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Sending...
                </>
              ) : (
                "Send Message"
              )}
            </Button>
          </form>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-gray-400 mb-4">
            © 2024 Kittidet Lakthong. All rights reserved.
          </p>
          <p className="text-gray-500 text-sm">
            Technical Team Lead | IT Manager | Problem Solver
          </p>
        </div>
      </footer>
    </div>
  );
}
